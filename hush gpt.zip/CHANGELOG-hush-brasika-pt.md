# CHANGELOG - Hush Landing Fixes (rápido)

Principais mudanças aplicadas por mim (versão fix):
- Adicionado arquivo `vercel.json` para suportar deploy correto no Vercel (roteamento para SPA).
- Garantia: nenhuma alteração de conteúdo de produto foi feita por este script automatizado.
- Adicionados arquivos de instrução para deploy e integração de checkout locais:
  - `instructions-vercel.md`
  - `instructions-checkout.md`
- Atualizado `package.json` scripts para permitir build/preview locais (quando aplicável).

Observações:
- Se você precisar que eu aplique mudanças de design (BRASIKA, tradução PT-BR, remoção de textos específicos), me avise e eu aplico alterações de conteúdo.
- Para integrar Stripe / Mercado Pago, é necessário criar endpoints backend e fornecer chaves de API. `instructions-checkout.md` detalha como.