# Instruções - Checkout (exemplo, placeholders)

Este projeto NÃO contém chaves reais. Use estas instruções para integrar um gateway.

## Stripe (exemplo)
1. No backend:
   - Endpoint POST /api/create-checkout-session
   - Use Stripe SDK para criar session:
     stripe.checkout.sessions.create({ payment_method_types: ['card'], line_items: [...], mode: 'payment', success_url: 'https://yourdomain/success?session_id={CHECKOUT_SESSION_ID}', cancel_url: 'https://yourdomain/cancel' })
2. Variáveis de ambiente:
   - STRIPE_SECRET=sk_test_...
3. Webhook:
   - Configure endpoint /api/webhook para receber eventos de pagamento e atualizar status de pedido.

## Mercado Pago (exemplo)
1. Criar preferência via API com itens, payer e back_urls.
2. Variáveis:
   - MP_ACCESS_TOKEN=YOUR_MP_ACCESS_TOKEN

## Carrinho local (frontend)
- Persistência: use localStorage 'hush_cart' para salvar itens.
- Antes do checkout, calcule frete por CEP (integração Correios ou API de frete) ou simule cálculo.