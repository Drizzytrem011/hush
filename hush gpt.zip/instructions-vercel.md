# Instruções Vercel - ajustes rápidos

1. Verifique o `package.json` scripts:
   - Para projetos Vite, os scripts devem incluir:
     - "build": "vite build"
     - "preview": "vite preview"
2. O arquivo `vercel.json` foi adicionado. Ele instrui a Vercel a usar o diretório `dist` e reescrever todas as rotas para `index.html`, adequado para SPA.
3. Como testar localmente:
   - npm ci
   - npm run build
   - npm run preview
4. Se o build falhar, abra os logs no dashboard da Vercel para identificar erros (dependências faltando, variáveis de ambiente).